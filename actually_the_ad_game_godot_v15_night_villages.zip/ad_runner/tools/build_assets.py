"""Build native Godot 3D character scenes and original generated placeholder SFX."""
from pathlib import Path
import math, random, wave, struct
root=Path(__file__).resolve().parents[1]
models=root/'models'; sounds=root/'sounds'
models.mkdir(exist_ok=True); sounds.mkdir(exist_ok=True)
C={
 'skin':'0.73, 0.82, 0.66','pale':'0.74, 0.76, 0.69','lilac':'0.72, 0.65, 0.77','mint':'0.53, 0.78, 0.72',
 'eyes':'0.06, 0.065, 0.08','mouth':'0.13, 0.13, 0.14','bone':'0.88, 0.82, 0.70','brown':'0.31, 0.24, 0.20',
 'tan':'0.57, 0.44, 0.34','cream':'0.76, 0.69, 0.55','black':'0.12, 0.12, 0.14','coat':'0.18, 0.19, 0.21',
 'red':'0.53, 0.19, 0.23','burgundy':'0.34, 0.15, 0.20','purple':'0.34, 0.28, 0.42','rust':'0.56, 0.32, 0.19',
 'metal':'0.39, 0.41, 0.41','brass':'0.64, 0.48, 0.23','teal':'0.28, 0.45, 0.43','mushroom':'0.62, 0.36, 0.34',
 'gray':'0.41, 0.39, 0.39','green':'0.34, 0.43, 0.30','white':'0.90, 0.87, 0.79'
}

def build(name, skin='skin', clothing='brown', face=True):
 parts=[]
 def part(n, pos, size, color, mesh='sphere', parent='Rig', rot=None):
  parts.append((n,parent,mesh,pos,size,color,rot or (0,0,0)))
 # Basic silhouette: head is intentionally bigger than torso, 2.1 units high.
 part('Torso',(0,.82,0),(.74,.83,.52),clothing)
 part('Head',(0,1.61,0),(1.20,1.13,1.04),skin,parent='Rig')
 for side, x in [('L',-.43),('R',.43)]:
  part('Arm'+side+'Pivot',(x,1.04,0),(.01,.01,.01),clothing,parent='Rig',mesh='pivot')
  part('Arm'+side,(0,-.23,0),(.27,.53,.30),clothing,parent='Rig/Arm'+side+'Pivot')
  part('Hand'+side,(0,-.52,-.035),(.25,.24,.25),skin,parent='Rig/Arm'+side+'Pivot')
  part('Leg'+side+'Pivot',(x*.55,.44,0),(.01,.01,.01),clothing,parent='Rig',mesh='pivot')
  part('Leg'+side,(0,-.17,0),(.30,.40,.34),clothing,parent='Rig/Leg'+side+'Pivot')
  part('Boot'+side,(0,-.36,-.09),(.34,.23,.46),'brown',parent='Rig/Leg'+side+'Pivot')
 if face:
  for side,x in [('L',-.25),('R',.25)]:
   part('Eye'+side,(x,1.66,-.61),(.22,.25,.08),'eyes')
  part('Mouth',(0,1.33,-.61),(.20,.11,.065),'mouth',mesh='box')
  part('ToothL',(-.08,1.29,-.65),(.045,.07,.025),'bone',mesh='box')
  part('ToothR',(.08,1.29,-.65),(.045,.07,.025),'bone',mesh='box')
 def add(n,p,s,c,m='sphere',par='Rig',rot=None):part(n,p,s,c,m,par,rot)
 if name=='hunter':
  # Player front points along +Z; the gameplay camera sees the hat, scarf and coat back.
  add('CoatTail',(0,.48,.18),(.80,.64,.44),'coat')
  add('CoatBack',(0,.85,.27),(.75,.76,.08),'coat','box')
  add('HatBrim',(0,2.14,0),(1.55,.12,1.46),'black','cylinder')
  add('HatCrown',(0,2.34,0),(.88,.38,.78),'black','cylinder')
  add('HatBand',(0,2.19,0),(.91,.065,.81),'red','cylinder')
  add('ScarfBack',(-.19,1.19,.34),(.25,.43,.15),'red')
  add('GunGrip',(.12,-.53,.38),(.13,.27,.23),'brown','box','Rig/ArmRPivot')
  add('GunBarrel',(.12,-.43,.66),(.14,.14,.60),'metal','cylinder','Rig/ArmRPivot',(90,0,0))
 elif name=='peasant':
  add('Hair',(0,2.00,.02),(1.21,.34,1.07),'brown')
  add('RaggedHem',(0,.46,0),(.79,.25,.56),'brown')
  add('Belt',(0,.62,-.20),(.77,.09,.10),'tan','box')
 elif name=='hood':
  add('HoodOuter',(0,1.81,.09),(1.38,1.43,1.26),'purple')
  add('HoodFace',(0,1.65,-.39),(1.02,.92,.34),skin)
  add('HoodShade',(0,1.98,-.50),(1.05,.16,.12),'purple')
  add('Robe',(0,.74,.04),(.86,.99,.65),'purple')
 elif name=='knight':
  add('ChestPlate',(0,.86,-.18),(.90,.71,.36),'rust')
  add('Helmet',(0,1.91,0),(1.32,.64,1.16),'rust')
  add('HelmetRidge',(0,2.22,0),(.16,.32,.90),'red')
  add('PauldronL',(-.55,1.05,0),(.43,.32,.53),'rust')
  add('PauldronR',(.55,1.05,0),(.43,.32,.53),'rust')
 elif name=='bishop':
  add('Robe',(0,.83,.06),(1.02,1.10,.72),'burgundy')
  add('Miter',(0,2.19,0),(1.05,.78,.58),'burgundy')
  add('MiterStripe',(0,2.22,-.32),(.13,.69,.06),'cream','box')
  add('MiterCross',(0,2.22,-.37),(.38,.10,.06),'cream','box')
  add('Staff',(.83,1.12,-.20),(.09,2.20,.09),'brown','cylinder')
  add('StaffRing',(.83,2.20,-.20),(.38,.38,.09),'brass','sphere')
 elif name=='butcher':
  add('Apron',(0,.80,-.30),(.80,.92,.10),'cream','box')
  add('Stitch',(.18,1.90,-.51),(.05,.26,.06),'brown','box','Rig',(0,0,34))
  add('CleaverGrip',(.63,.42,-.20),(.11,.37,.12),'brown','box')
  add('CleaverBlade',(.67,.37,-.45),(.38,.44,.09),'metal','box')
 elif name=='bell':
  add('Hump',(0,1.13,.36),(.79,.81,.69),'brown')
  add('Cowl',(0,1.78,.29),(1.28,1.14,1.21),'brown')
  add('FacePatch',(0,1.57,-.40),(1.03,.89,.35),'lilac')
  add('Bell',(-.67,.28,-.24),(.49,.49,.43),'brass','cylinder')
  add('BellLip',(-.67,.07,-.24),(.55,.10,.48),'brass','cylinder')
 elif name=='fungus':
  add('Helmet',(0,1.91,.02),(1.32,.51,1.14),'green')
  add('Armor',(0,.88,-.15),(.88,.77,.36),'teal')
  add('MushroomStem',(.50,1.55,.10),(.15,.62,.17),'cream','cylinder')
  add('MushroomCap',(.51,1.88,.10),(.76,.30,.69),'mushroom')
  add('Shield',(.69,.66,-.40),(.56,.75,.13),'metal')
 elif name=='doctor':
  add('HatBrim',(0,2.03,0),(1.50,.12,1.36),'black','cylinder')
  add('HatTop',(0,2.22,0),(.83,.38,.80),'purple','cylinder')
  add('Beak',(0,1.48,-.57),(.31,.25,.72),'bone','sphere','Rig',(-15,0,0))
  add('Robe',(0,.80,.03),(.88,1.02,.61),'purple')
 elif name=='cathedral':
  add('Robe',(0,.78,.06),(1.03,1.11,.79),'burgundy')
  add('CrownBase',(0,2.18,0),(1.26,.27,1.06),'brass','cylinder')
  for i,x in enumerate([-.40,0,.40]):
   add('CrownSpire'+str(i),(x,2.51,0),(.22,.55,.22),'brass','cone')
  for i,x in enumerate([-.25,.25]):
   add('ChestFace'+str(i),(x,.74,-.45),(.34,.35,.09),'skin')
   add('ChestEye'+str(i),(x,.78,-.54),(.11,.12,.04),'eyes')
  add('ChestSplit',(0,.40,-.52),(.24,.09,.07),'mouth','box')
  # Size handled in the enemy scene so gameplay spacing stays reasonable.
 # Assemble scene with shared unit geometry and distinct matte palette.
 lines=[f'[gd_scene load_steps={len(C)+6} format=3]','', '[ext_resource type="Script" path="res://scripts/character_visual.gd" id="1"]']
 for shape,kind in [('sphere','SphereMesh'),('cylinder','CylinderMesh'),('box','BoxMesh'),('cone','CylinderMesh')]:
  lines+=['[sub_resource type="'+kind+'" id="mesh_'+shape+'"]']
  if shape=='sphere': lines+=['radius = 0.5','height = 1.0','radial_segments = 12','rings = 6']
  elif shape=='cylinder':lines+=['top_radius = 0.5','bottom_radius = 0.5','height = 1.0','radial_segments = 12']
  elif shape=='cone':lines+=['top_radius = 0.01','bottom_radius = 0.5','height = 1.0','radial_segments = 8']
  else:lines+=['size = Vector3(1, 1, 1)']
 for color,value in C.items():
  lines+=['[sub_resource type="StandardMaterial3D" id="mat_'+color+'"]','albedo_color = Color('+value+', 1)','roughness = 0.85']
 lines+=['',f'[node name="{name.title()}" type="Node3D"]','script = ExtResource("1")']
 if name!='hunter':lines+=['attack_direction = -1.0']
 lines+=['[node name="Rig" type="Node3D" parent="."]']
 pivots={'Rig'}
 for n,par,mesh,pos,size,color,rot in parts:
  if par not in pivots: raise RuntimeError((name,par,n))
  lines+=['[node name="'+n+'" type="'+('Node3D' if mesh=='pivot' else 'MeshInstance3D')+'" parent="'+par+'"]']
  if mesh!='pivot':lines+=['mesh = SubResource("mesh_'+mesh+'")','material_override = SubResource("mat_'+color+'")']
  lines+=['position = Vector3('+', '.join(str(v) for v in pos)+')']
  if mesh!='pivot':lines+=['scale = Vector3('+', '.join(str(v) for v in size)+')']
  if any(rot):lines+=['rotation_degrees = Vector3('+', '.join(str(v) for v in rot)+')']
  if mesh=='pivot':pivots.add(par+'/'+n)
 (models/(name+'.tscn')).write_text('\n'.join(lines)+'\n')

for name,skin,clothing,face in [
 ('hunter','pale','coat',False),('peasant','skin','brown',True),('hood','skin','purple',True),
 ('knight','skin','rust',True),('bishop','skin','burgundy',True),('butcher','skin','tan',True),
 ('bell','lilac','brown',True),('fungus','mint','teal',True),('doctor','lilac','purple',True),
 ('cathedral','skin','burgundy',True)]:build(name,skin,clothing,face)

# Short original synthesized game sounds, mono 44.1 kHz PCM WAV.
rate=44100
specs={'shoot':(.105,620,190,.13),'enemy_hit':(.13,260,90,.20),'enemy_death':(.34,180,45,.27),
       'player_hit':(.20,400,115,.20),'player_death':(.55,245,38,.29),'soldier_death':(.28,310,65,.23),
       'enemy_attack':(.14,180,95,.18),'upgrade':(.35,430,860,.20)}
for name,(duration,start,end,volume) in specs.items():
 rng=random.Random(101+len(name)); samples=[]
 for i in range(int(duration*rate)):
  t=i/rate; f=start+(end-start)*t/duration
  phase=2*math.pi*(start*t+(end-start)*t*t/(2*duration))
  envelope=(1-math.exp(-t*190))*math.exp(-4.7*t/duration)
  noise=(rng.random()*2-1)*(.28 if name in ('enemy_hit','enemy_death','player_hit') else .11)
  wave_value=math.sin(phase)+.24*math.sin(phase*1.93)+noise
  samples.append(int(max(-1,min(1,wave_value*envelope*volume))*32767))
 with wave.open(str(sounds/(name+'.wav')),'wb') as out:
  out.setnchannels(1);out.setsampwidth(2);out.setframerate(rate)
  out.writeframes(struct.pack('<'+'h'*len(samples),*samples))
print('Generated 10 native Godot character scenes and 8 WAV sounds')
