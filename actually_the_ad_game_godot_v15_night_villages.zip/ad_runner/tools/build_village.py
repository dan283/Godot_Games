"""Generate the editable low-poly village prop scenes. Run from project root.
Regeneration overwrites custom edits to these three scenes.
"""
from pathlib import Path

root = Path(__file__).resolve().parents[1] / "props"


def render(name, materials, shapes, parts, lights=()):
    lines = [f'[gd_scene load_steps={1 + len(materials) + len(shapes)} format=3]', '']
    for key, color in materials.items():
        lines += [f'[sub_resource type="StandardMaterial3D" id="{key}"]',
                  f'albedo_color = Color({color[0]}, {color[1]}, {color[2]}, 1)',
                  'roughness = 0.9']
        if key in {'amber', 'violet', 'fire'}:
            lines += ['emission_enabled = true', f'emission = Color({color[0]}, {color[1]}, {color[2]}, 1)', 'emission_energy_multiplier = 2.2']
    for key, (kind, fields) in shapes.items():
        lines.append(f'[sub_resource type="{kind}" id="{key}"]')
        lines += fields
    lines += ['', f'[node name="{name}" type="Node3D"]']
    for label, shape, material, xyz, scale, rotation in parts:
        lines += [f'[node name="{label}" type="MeshInstance3D" parent="."]',
                  f'mesh = SubResource("{shape}")', f'material_override = SubResource("{material}")',
                  f'position = Vector3({xyz[0]}, {xyz[1]}, {xyz[2]})']
        if scale != (1, 1, 1):
            lines.append(f'scale = Vector3({scale[0]}, {scale[1]}, {scale[2]})')
        if rotation:
            lines.append(f'rotation_degrees = Vector3({rotation[0]}, {rotation[1]}, {rotation[2]})')
    for label, xyz, color, energy, distance in lights:
        lines += [f'[node name="{label}" type="OmniLight3D" parent="."]',
                  f'position = Vector3({xyz[0]}, {xyz[1]}, {xyz[2]})',
                  f'light_color = Color({color[0]}, {color[1]}, {color[2]}, 1)',
                  f'light_energy = {energy}', f'omni_range = {distance}', 'shadow_enabled = false']
    (root / f'{name.lower()}.tscn').write_text('\n'.join(lines) + '\n')


def part(label, shape, mat, pos, scale=(1, 1, 1), rotation=None):
    return (label, shape, mat, pos, scale, rotation)


house_materials = {
    'plaster': (.35, .32, .33), 'stone': (.20, .23, .26), 'timber': (.14, .12, .15),
    'roof': (.18, .12, .17), 'roof_ridge': (.26, .18, .20), 'door': (.12, .09, .11),
    'amber': (1.0, .47, .11), 'frame': (.09, .075, .10),
}
house_shapes = {
    'wall': ('BoxMesh', ['size = Vector3(5.2, 3.1, 4.5)']),
    'base': ('BoxMesh', ['size = Vector3(5.7, 0.3, 4.9)']),
    'beam': ('BoxMesh', ['size = Vector3(0.22, 3.2, 0.24)']),
    'roof_panel': ('BoxMesh', ['size = Vector3(3.25, 0.28, 5.15)']),
    'ridge': ('BoxMesh', ['size = Vector3(0.35, 0.30, 5.2)']),
    'window': ('BoxMesh', ['size = Vector3(0.73, 0.86, 0.08)']),
    'mullion': ('BoxMesh', ['size = Vector3(0.09, 0.91, 0.12)']),
    'door_mesh': ('BoxMesh', ['size = Vector3(1.1, 2.0, 0.1)']),
    'chimney': ('BoxMesh', ['size = Vector3(0.8, 2.0, 0.8)']),
}
house_parts = [
    part('Foundation', 'base', 'stone', (0, .08, 0)),
    part('PlasterWalls', 'wall', 'plaster', (0, 1.65, 0)),
    part('RoofLeft', 'roof_panel', 'roof', (-1.28, 3.72, 0), rotation=(0, 0, -31)),
    part('RoofRight', 'roof_panel', 'roof', (1.28, 3.72, 0), rotation=(0, 0, 31)),
    part('RoofRidge', 'ridge', 'roof_ridge', (0, 4.47, 0)),
    part('FrontDoor', 'door_mesh', 'door', (0, 1.07, -2.31)),
    part('Chimney', 'chimney', 'stone', (1.75, 4.05, 1.05)),
]
for side, x in [('L', -2.48), ('R', 2.48)]:
    house_parts += [part(f'FrontBeam{side}', 'beam', 'timber', (x, 1.65, -2.31)),
                    part(f'RearBeam{side}', 'beam', 'timber', (x, 1.65, 2.31))]
for side, x in [('L', -1.65), ('R', 1.65)]:
    house_parts += [part(f'Window{side}', 'window', 'amber', (x, 1.9, -2.34)),
                    part(f'WindowBar{side}', 'mullion', 'frame', (x, 1.9, -2.42))]
render('VillageHouse', house_materials, house_shapes, house_parts,
       [('WarmWindows', (0, 2.0, -2.7), (1.0, .55, .25), .95, 7.0)])

chapel_materials = {
    'stone': (.22, .24, .31), 'trim': (.37, .36, .42), 'roof': (.12, .13, .20),
    'door': (.12, .08, .13), 'violet': (.72, .32, .74), 'amber': (1.0, .61, .24),
}
chapel_shapes = {
    'body': ('BoxMesh', ['size = Vector3(5.0, 4.1, 7.0)']),
    'tower': ('BoxMesh', ['size = Vector3(2.3, 6.8, 2.3)']),
    'spire': ('CylinderMesh', ['top_radius = 0.04', 'bottom_radius = 1.72', 'height = 2.7', 'radial_segments = 4']),
    'roof': ('BoxMesh', ['size = Vector3(3.2, 0.28, 7.6)']),
    'window': ('BoxMesh', ['size = Vector3(0.62, 1.5, 0.09)']),
    'slab': ('BoxMesh', ['size = Vector3(1.3, 2.3, 0.11)']),
    'cross': ('BoxMesh', ['size = Vector3(0.14, 0.85, 0.14)']),
}
chapel_parts = [
    part('Nave', 'body', 'stone', (0, 2.1, .4)),
    part('NorthRoof', 'roof', 'roof', (-1.3, 4.65, .4), rotation=(0, 0, -30)),
    part('SouthRoof', 'roof', 'roof', (1.3, 4.65, .4), rotation=(0, 0, 30)),
    part('BellTower', 'tower', 'stone', (0, 4.8, -3.25)),
    part('Steeple', 'spire', 'roof', (0, 9.45, -3.25), rotation=(0, 45, 0)),
    part('Door', 'slab', 'door', (0, 1.2, -4.47)),
    part('Cross', 'cross', 'trim', (0, 11.07, -3.25)),
]
for side, x in [('Left', -2.55), ('Right', 2.55)]:
    for j, z in enumerate([-1.4, 1.2, 3.3]):
        chapel_parts.append(part(f'Glass{side}{j}', 'window', 'violet', (x, 2.55, z), rotation=(0, 90, 0)))
render('VillageChapel', chapel_materials, chapel_shapes, chapel_parts,
       [('WindowGlow', (0, 3.1, -4.4), (.7, .4, 1.0), .8, 8.0)])

lamp_materials = {'iron': (.11, .12, .15), 'amber': (1.0, .60, .18), 'stone': (.27, .27, .29)}
lamp_shapes = {
    'pole': ('CylinderMesh', ['top_radius = 0.07', 'bottom_radius = 0.12', 'height = 3.4', 'radial_segments = 8']),
    'base': ('BoxMesh', ['size = Vector3(0.8, 0.42, 0.8)']),
    'lamp': ('SphereMesh', ['radius = 0.5', 'height = 1.0', 'radial_segments = 8', 'rings = 4']),
    'hood': ('CylinderMesh', ['top_radius = 0.18', 'bottom_radius = 0.58', 'height = 0.45', 'radial_segments = 8']),
}
lamp_parts = [part('Base', 'base', 'stone', (0, .19, 0)),
              part('IronPost', 'pole', 'iron', (0, 1.85, 0)),
              part('LanternGlow', 'lamp', 'amber', (0, 3.46, 0), (.48, .55, .48)),
              part('LanternHood', 'hood', 'iron', (0, 3.92, 0))]
render('VillageLantern', lamp_materials, lamp_shapes, lamp_parts,
       [('LanternLight', (0, 3.45, 0), (1.0, .58, .30), 1.5, 9.0)])

fence_materials = {'timber': (.17, .13, .14), 'stone': (.26, .27, .29)}
fence_shapes = {
    'post': ('BoxMesh', ['size = Vector3(0.25, 1.3, 0.28)']),
    'rail': ('BoxMesh', ['size = Vector3(4.4, 0.14, 0.17)']),
    'plinth': ('BoxMesh', ['size = Vector3(0.42, 0.25, 0.42)']),
}
fence_parts = [part('UpperRail', 'rail', 'timber', (0, 1.05, 0)),
               part('LowerRail', 'rail', 'timber', (0, .62, 0))]
for side, x in [('Left', -2.05), ('Right', 2.05)]:
    fence_parts += [part(f'Post{side}', 'post', 'timber', (x, .65, 0)),
                    part(f'Foot{side}', 'plinth', 'stone', (x, .1, 0))]
render('VillageFence', fence_materials, fence_shapes, fence_parts)
