extends Node3D
class_name RunnerEffects

var rng := RandomNumberGenerator.new()
var spark_mesh: SphereMesh
var last_hit_ms: int = -1000

func _ready() -> void:
    rng.randomize()
    spark_mesh = SphereMesh.new()
    spark_mesh.radius = 0.5
    spark_mesh.height = 1.0
    spark_mesh.radial_segments = 6
    spark_mesh.rings = 3

func upgrade(at: Vector3, title: String) -> void:
    burst(at + Vector3.UP * 1.4, Color(0.28, 1.0, 0.45), 16, 2.3, 0.52)
    floating_text(at + Vector3.UP * 2.4, title, Color(0.58, 1.0, 0.62))

func kill(at: Vector3, cash: int, boss: bool) -> void:
    burst(at + Vector3.UP * (1.8 if boss else 0.85), Color(0.85, 0.3, 0.28), 22 if boss else 9, 2.0 if boss else 0.95, 0.62)
    floating_text(at + Vector3.UP * (3.0 if boss else 1.65), "+$%d" % cash, Color(1.0, 0.88, 0.35))

func hit(at: Vector3) -> void:
    var now: int = Time.get_ticks_msec()
    if now - last_hit_ms < 70:
        return
    last_hit_ms = now
    burst(at + Vector3.UP * 0.9, Color(1.0, 0.83, 0.3), 3, 0.42, 0.18)

func player_damage(at: Vector3) -> void:
    burst(at + Vector3.UP, Color(1.0, 0.22, 0.18), 9, 1.0, 0.30)
    floating_text(at + Vector3.UP * 2.0, "HIT!", Color(1.0, 0.4, 0.35))

func soldier_down(at: Vector3) -> void:
    burst(at + Vector3.UP * 0.6, Color(0.45, 0.7, 1.0), 6, 0.75, 0.34)

func heal(at: Vector3) -> void:
    burst(at + Vector3.UP, Color(0.36, 1.0, 0.65), 8, 1.0, 0.48)
    floating_text(at + Vector3.UP * 1.8, "+1 HP", Color(0.5, 1.0, 0.7))

func burst(at: Vector3, color: Color, count: int, radius: float, life: float) -> void:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    for i in range(count):
        var spark := MeshInstance3D.new()
        spark.mesh = spark_mesh
        spark.material_override = material
        var size: float = rng.randf_range(0.11, 0.24)
        spark.scale = Vector3.ONE * size
        add_child(spark)
        spark.global_position = at
        var offset := Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(0.35, 1.55), rng.randf_range(-1.0, 1.0)).normalized() * radius
        var tween := create_tween()
        tween.set_parallel(true)
        tween.tween_property(spark, "position", spark.position + offset, life).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
        tween.tween_property(spark, "scale", Vector3.ZERO, life)
        tween.set_parallel(false)
        tween.tween_callback(spark.queue_free)

func floating_text(at: Vector3, message: String, tint: Color) -> void:
    var label := Label3D.new()
    label.text = message
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.font_size = 64
    label.pixel_size = 0.007
    label.outline_size = 8
    label.modulate = tint
    add_child(label)
    label.global_position = at
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(label, "position", label.position + Vector3.UP * 1.2, 0.8).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    tween.tween_property(label, "modulate:a", 0.0, 0.8)
    tween.set_parallel(false)
    tween.tween_callback(label.queue_free)
