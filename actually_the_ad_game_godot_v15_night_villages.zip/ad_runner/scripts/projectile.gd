extends Node3D
class_name RunnerProjectile

var target: Node3D
var damage: float = 1.0
var speed: float = 38.0
var lifetime: float = 2.0
var weapon: String = "bolt"
var enemies: Node3D
var visual_level: int = 0
var aim_offset: Vector3 = Vector3.ZERO
var trail_clock: float = 0.0
var color: Color = Color.WHITE

func launch(victim: Node3D, amount: float, type: String = "bolt", enemy_container: Node3D = null, upgrade_level: int = 0, offset: Vector3 = Vector3.ZERO) -> void:
    target = victim
    damage = amount
    weapon = type
    enemies = enemy_container
    visual_level = upgrade_level
    aim_offset = offset
    speed = 54.0 if weapon == "bolt" else (31.0 if weapon == "flame" else 46.0)
    color = Color(0.30, 0.78, 1.0) if weapon == "bolt" else (Color(1.0, 0.30, 0.07) if weapon == "flame" else Color(1.0, 0.79, 0.27))
    var core := $Mesh as MeshInstance3D
    var mesh_shape: SphereMesh = SphereMesh.new()
    mesh_shape.radius = 0.5
    mesh_shape.height = 1.0
    mesh_shape.radial_segments = 8
    mesh_shape.rings = 4
    core.mesh = mesh_shape
    core.material_override = _material(color)
    var growth: float = minf(1.8, 1.0 + float(visual_level) * 0.11)
    if weapon == "bolt":
        core.scale = Vector3(0.20, 0.20, 0.85) * growth
    elif weapon == "flame":
        core.scale = Vector3.ONE * 0.63 * growth
        _add_halo(Color(1.0, 0.7, 0.15, 0.36), Vector3.ONE * 1.05 * growth)
    else:
        core.scale = Vector3.ONE * 0.28 * growth
    if weapon == "bolt":
        _add_halo(Color(0.35, 0.86, 1.0, 0.33), Vector3(0.42, 0.42, 1.28) * growth)

func _material(tint: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.emission_enabled = true
    mat.emission = Color(tint.r, tint.g, tint.b)
    mat.emission_energy_multiplier = 2.0
    if tint.a < 1.0:
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mat.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
    return mat

func _add_halo(tint: Color, size: Vector3) -> void:
    var halo := MeshInstance3D.new()
    halo.mesh = $Mesh.mesh
    halo.material_override = _material(tint)
    halo.scale = size
    add_child(halo)

func _process(delta: float) -> void:
    lifetime -= delta
    if lifetime <= 0.0 or not is_instance_valid(target):
        queue_free()
        return
    if target is RunnerGate and ((target as RunnerGate).unlocked or (target as RunnerGate).triggered):
        queue_free()
        return
    if target is RunnerEnemy and (target as RunnerEnemy).health <= 0.0:
        queue_free()
        return
    var target_center: Vector3 = target.global_position + Vector3(0.0, 1.5 if target is RunnerGate else 0.8, 0.0)
    var aim: Vector3 = target_center + aim_offset
    if global_position.distance_to(aim) > 0.01:
        look_at(aim, Vector3.UP)
    global_position = global_position.move_toward(aim, speed * delta)
    trail_clock -= delta
    if trail_clock <= 0.0:
        trail_clock = 0.105 if visual_level < 2 else 0.065
        _trail()
    if global_position.distance_to(aim) < 0.8:
        if target is RunnerGate:
            (target as RunnerGate).take_shot(damage)
        elif target is RunnerEnemy:
            (target as RunnerEnemy).take_damage(damage)
            if weapon == "flame":
                _splash(target_center)
            elif weapon == "bolt" and visual_level >= 2:
                _chain(target_center)
        _impact(target_center)
        queue_free()

func _trail() -> void:
    var spark := MeshInstance3D.new()
    spark.mesh = $Mesh.mesh
    spark.material_override = $Mesh.material_override
    get_parent().add_child(spark)
    spark.global_position = global_position
    var size: float = 0.14 if weapon == "scatter" else (0.24 if weapon == "bolt" else 0.38)
    spark.scale = Vector3.ONE * size * minf(1.6, 1.0 + visual_level * 0.1)
    var tween := spark.create_tween()
    tween.tween_property(spark, "scale", Vector3.ZERO, 0.19)
    tween.tween_callback(spark.queue_free)

func _splash(at: Vector3) -> void:
    if enemies == null:
        return
    var radius: float = minf(4.4, 2.7 + visual_level * 0.18)
    for child in enemies.get_children():
        var enemy: RunnerEnemy = child as RunnerEnemy
        if enemy != null and enemy != target and enemy.health > 0.0 and enemy.global_position.distance_to(at) < radius:
            enemy.take_damage(damage * 0.48)
    _pulse(at, Color(1.0, 0.42, 0.09, 0.50), radius * 0.55)

func _chain(at: Vector3) -> void:
    if enemies == null:
        return
    var nearby: RunnerEnemy
    var best_distance: float = 3.0 + minf(2.0, visual_level * 0.25)
    for child in enemies.get_children():
        var enemy: RunnerEnemy = child as RunnerEnemy
        if enemy != null and enemy != target and enemy.health > 0.0:
            var distance: float = enemy.global_position.distance_to(at)
            if distance < best_distance:
                nearby = enemy
                best_distance = distance
    if nearby != null:
        nearby.take_damage(damage * 0.38)
        var endpoint: Vector3 = nearby.global_position + Vector3.UP * 0.8
        var beam := MeshInstance3D.new()
        var beam_mesh := BoxMesh.new()
        beam_mesh.size = Vector3(0.085, 0.085, best_distance)
        beam.mesh = beam_mesh
        beam.material_override = _material(Color(0.3, 0.9, 1.0))
        get_parent().add_child(beam)
        beam.global_position = (at + endpoint) * 0.5
        beam.look_at(endpoint, Vector3.UP)
        var tween := beam.create_tween()
        tween.tween_property(beam, "scale", Vector3(0.01, 0.01, 1.0), 0.17)
        tween.tween_callback(beam.queue_free)

func _impact(at: Vector3) -> void:
    var size: float = 0.45 if weapon == "scatter" else (0.7 if weapon == "bolt" else 0.95)
    _pulse(at, Color(color.r, color.g, color.b, 0.45), size * minf(1.8, 1.0 + visual_level * 0.10))

func _pulse(at: Vector3, tint: Color, radius: float) -> void:
    var flash := MeshInstance3D.new()
    var shape := SphereMesh.new()
    shape.radius = 0.5
    shape.height = 1.0
    shape.radial_segments = 10
    shape.rings = 5
    flash.mesh = shape
    flash.material_override = _material(tint)
    get_parent().add_child(flash)
    flash.global_position = at
    flash.scale = Vector3.ONE * 0.15
    var tween := flash.create_tween()
    tween.set_parallel(true)
    tween.tween_property(flash, "scale", Vector3.ONE * radius, 0.27).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    tween.tween_property(flash, "transparency", 1.0, 0.27)
    tween.set_parallel(false)
    tween.tween_callback(flash.queue_free)
