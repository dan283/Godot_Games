extends Node3D
class_name CharacterVisual

@export var animation_speed: float = 8.0
@export var bob_amount: float = 0.045
@export var attack_direction: float = 1.0

var motion: float = 0.0
var clock: float = 0.0
var death_clock: float = -1.0
var hit_clock: float = 0.0
var attack_clock: float = 0.0

@onready var rig: Node3D = $Rig
@onready var left_arm: Node3D = $Rig/ArmLPivot
@onready var right_arm: Node3D = $Rig/ArmRPivot
@onready var left_leg: Node3D = $Rig/LegLPivot
@onready var right_leg: Node3D = $Rig/LegRPivot

func set_moving(value: bool) -> void:
    motion = move_toward(motion, 1.0 if value else 0.0, 0.12)

func hit() -> void:
    hit_clock = 0.16

func attack() -> void:
    if death_clock < 0.0:
        attack_clock = 0.22

func die() -> void:
    death_clock = 0.0

func _process(delta: float) -> void:
    if death_clock >= 0.0:
        death_clock += delta
        rig.rotation.z = minf(death_clock * 4.5, 1.45)
        rig.position.y = -minf(death_clock * 0.9, 0.3)
        return
    clock += delta * animation_speed
    hit_clock = maxf(0.0, hit_clock - delta)
    attack_clock = maxf(0.0, attack_clock - delta)
    var stride: float = sin(clock) * motion
    left_leg.rotation.x = stride * 0.42
    right_leg.rotation.x = -stride * 0.42
    left_arm.rotation.x = -stride * 0.35
    var attack_swing: float = sin((1.0 - attack_clock / 0.22) * PI) if attack_clock > 0.0 else 0.0
    right_arm.rotation.x = stride * 0.35 + attack_swing * attack_direction * 1.1
    rig.position.y = absf(sin(clock)) * bob_amount * motion
    rig.rotation.z = 0.13 if hit_clock > 0.0 else sin(clock * 0.5) * 0.018
    rig.rotation.x = attack_swing * attack_direction * 0.12
