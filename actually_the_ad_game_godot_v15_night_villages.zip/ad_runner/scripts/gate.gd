extends Node3D
class_name RunnerGate

@export var upgrade: String = "damage"
@export var amount: float = 2.0
@export var title: String = "+2 DAMAGE"
@export var positive: bool = true
@export_group("Shootable Shield")
@export_range(0.25, 30.0, 0.05) var maximum_shield: float = 2.45
var triggered: bool = false
var shield: float = 2.45
var unlocked: bool = false
var vanishing: bool = false
var pickup_beacon: MeshInstance3D

func _process(delta: float) -> void:
    if unlocked and not triggered and pickup_beacon != null:
        pickup_beacon.rotation.y += delta * 2.5
        var pulse: float = 0.92 + 0.12 * sin(float(Time.get_ticks_msec()) * 0.008)
        pickup_beacon.scale = Vector3(pulse, 1.0, pulse)

func configure(gate_title: String, gate_upgrade: String, gate_amount: float, is_positive: bool) -> void:
    title = gate_title
    upgrade = gate_upgrade
    amount = gate_amount
    positive = is_positive
    $Text.text = title
    shield = maximum_shield
    _update_display()
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.1, 0.9, 0.3, 0.5) if positive else Color(1.0, 0.2, 0.13, 0.5)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    $Panel.material_override = mat

func take_shot(power: float) -> void:
    if unlocked or triggered:
        return
    shield = maxf(0.0, shield - power)
    unlocked = shield <= 0.0
    _update_display()
    var hit_tween := create_tween()
    $Panel.scale = Vector3(1.09, 1.08, 1.0)
    hit_tween.tween_property($Panel, "scale", Vector3.ONE, 0.17)
    if unlocked:
        _shatter_panel()
        $Panel.hide()
        $ShieldBar.hide()
        $Text.modulate = Color(0.75, 1.0, 0.5)
        $Shield.text = "RUN THROUGH"
        _show_pickup()

func _show_pickup() -> void:
    pickup_beacon = MeshInstance3D.new()
    var shape := CylinderMesh.new()
    shape.top_radius = 0.08
    shape.bottom_radius = 0.60
    shape.height = 2.6
    pickup_beacon.mesh = shape
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(0.28, 1.0, 0.49, 0.56)
    material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    pickup_beacon.material_override = material
    add_child(pickup_beacon)
    pickup_beacon.position.y = 1.3

func _update_display() -> void:
    $Shield.text = "READY  ✓" if unlocked else "SHOOT  %.2f / %.2f" % [shield, maximum_shield]
    $Shield.modulate = Color(0.45, 1.0, 0.48) if unlocked else Color(1.0, 0.86, 0.4)
    $ShieldBar.scale.x = maxf(0.01, shield / maximum_shield)

func apply(player: RunnerPlayer) -> void:
    if triggered or not unlocked:
        return
    triggered = true
    match upgrade:
        "damage": player.damage = maxf(0.5, player.damage + amount)
        "soldiers":
            player.soldier_count = clampi(player.soldier_count + int(amount), 1, 24)
            player.refresh_formation()
        "fire_rate": player.fire_interval = clampf(player.fire_interval * amount, 0.07, 1.5)
        "cash": player.cash = maxi(0, player.cash + int(amount))
        "multiplier": player.cash_multiplier = mini(10, player.cash_multiplier * int(amount))
        "health": player.health = clampf(player.health + amount, 0.0, player.maximum_health)
        "weapon_scatter": player.set_weapon("scatter")
        "weapon_flame": player.set_weapon("flame")
        "weapon_bolt": player.set_weapon("bolt")
    if upgrade in ["damage", "fire_rate", "weapon_scatter", "weapon_flame", "weapon_bolt"]:
        player.boost_visuals()

func vanish(claimed: bool) -> void:
    if vanishing:
        return
    vanishing = true
    triggered = true
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(self, "position", position + Vector3.DOWN * 2.4, 0.38).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
    tween.tween_property(self, "scale", Vector3(0.7, 0.2, 0.7) if claimed else Vector3(0.8, 0.1, 0.8), 0.38)
    tween.set_parallel(false)
    tween.tween_callback(queue_free)

func _shatter_panel() -> void:
    var random := RandomNumberGenerator.new()
    random.randomize()
    var fragment_mesh := BoxMesh.new()
    fragment_mesh.size = Vector3(1.08, 0.94, 0.14)
    var fragment_material := StandardMaterial3D.new()
    fragment_material.albedo_color = Color(0.37, 1.0, 0.55)
    fragment_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    for row in range(3):
        for column in range(4):
            var shard := MeshInstance3D.new()
            shard.mesh = fragment_mesh
            shard.material_override = fragment_material
            get_parent().add_child(shard)
            var local_center := Vector3((float(column) - 1.5) * 1.14, 0.55 + float(row) * 1.05, 0.0)
            shard.global_position = to_global(local_center)
            var outward := Vector3((float(column) - 1.5) * random.randf_range(0.6, 1.0), random.randf_range(0.4, 2.2), random.randf_range(-1.4, 1.4))
            var tween := shard.create_tween()
            tween.set_parallel(true)
            tween.tween_property(shard, "global_position", shard.global_position + outward, 0.58).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
            tween.tween_property(shard, "rotation_degrees", Vector3(random.randf_range(-130.0, 130.0), random.randf_range(-180.0, 180.0), random.randf_range(-160.0, 160.0)), 0.58)
            tween.tween_property(shard, "scale", Vector3.ZERO, 0.58).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
            tween.set_parallel(false)
            tween.tween_callback(shard.queue_free)
