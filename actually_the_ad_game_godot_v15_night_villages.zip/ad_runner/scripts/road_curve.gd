extends RefCounted
class_name RunnerRoad

# Shared path for the road meshes, player, gates, enemies, and scenery.
static func center_x(z: float) -> float:
    return 3.8 * sin(z / 51.0) + 1.15 * sin(z / 23.0)

static func slope(z: float) -> float:
    return 3.8 / 51.0 * cos(z / 51.0) + 1.15 / 23.0 * cos(z / 23.0)
