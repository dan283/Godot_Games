extends CanvasLayer
class_name RunnerHUD

signal character_selected(choice: String)
var message_clock: float = 4.0
var selection_screen: Control
var upgrade_banner: PanelContainer

func show_character_select() -> void:
    selection_screen = ColorRect.new()
    selection_screen.set_anchors_preset(Control.PRESET_FULL_RECT)
    selection_screen.color = Color(0.025, 0.035, 0.055, 0.94)
    add_child(selection_screen)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    selection_screen.add_child(center)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 22)
    center.add_child(layout)
    var heading := Label.new()
    heading.text = "THE LAST HUNT"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 52)
    heading.add_theme_color_override("font_color", Color(0.97, 0.84, 0.58))
    layout.add_child(heading)
    var subtitle := Label.new()
    subtitle.text = "Choose your hunter  •  Shatter a gate, then run through its green beacon"
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_font_size_override("font_size", 20)
    layout.add_child(subtitle)
    var cards := HBoxContainer.new()
    cards.add_theme_constant_override("separation", 18)
    layout.add_child(cards)
    _add_character_card(cards, "hunter", "HUNTER", "ARC BOLT", "Fast firing • 12 HP\nAccurate shots and a quick stride", Color(0.36, 0.65, 0.95))
    _add_character_card(cards, "guardian", "GUARDIAN", "SCATTER SHOT", "18 HP • 4 soldiers\nRegenerates 1 HP every 9 seconds", Color(0.95, 0.67, 0.31))
    _add_character_card(cards, "alchemist", "ALCHEMIST", "FIRE BOMB", "10 HP • splash damage\nExplosions hurt nearby enemies", Color(0.76, 0.46, 0.92))
    var footer := Label.new()
    footer.text = "A / D or arrow keys to steer  •  Automatic shooting  •  Aim with your lane"
    footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    footer.add_theme_font_size_override("font_size", 17)
    layout.add_child(footer)

func _add_character_card(cards: HBoxContainer, key: String, title: String, weapon: String, description: String, tint: Color) -> void:
    var button := Button.new()
    button.custom_minimum_size = Vector2(315, 205)
    button.text = "%s\n\n%s\n\n%s\n\nSELECT" % [title, weapon, description]
    button.add_theme_font_size_override("font_size", 20)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.09, 0.12, 0.17)
    style.border_color = tint
    style.set_border_width_all(3)
    style.set_corner_radius_all(15)
    button.add_theme_stylebox_override("normal", style)
    button.add_theme_color_override("font_color", tint)
    button.pressed.connect(func() -> void:
        selection_screen.queue_free()
        character_selected.emit(key)
    )
    cards.add_child(button)

func show_upgrade(title: String, weapon: String) -> void:
    if is_instance_valid(upgrade_banner):
        upgrade_banner.queue_free()
    upgrade_banner = PanelContainer.new()
    upgrade_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
    upgrade_banner.offset_left = -250.0
    upgrade_banner.offset_top = 190.0
    upgrade_banner.offset_right = 250.0
    upgrade_banner.offset_bottom = 265.0
    upgrade_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.04, 0.20, 0.10, 0.96)
    style.border_color = Color(0.45, 1.0, 0.48)
    style.set_border_width_all(3)
    style.set_corner_radius_all(12)
    upgrade_banner.add_theme_stylebox_override("panel", style)
    add_child(upgrade_banner)
    var label := Label.new()
    label.text = "✓  UPGRADE ACQUIRED\n%s" % title
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 25)
    label.add_theme_color_override("font_color", Color(0.65, 1.0, 0.70))
    upgrade_banner.add_child(label)
    var tween := create_tween()
    tween.tween_interval(2.2)
    tween.tween_property(upgrade_banner, "modulate:a", 0.0, 0.55)
    tween.tween_callback(upgrade_banner.queue_free)

func show_damage_flash() -> void:
    var flash := ColorRect.new()
    flash.color = Color(0.95, 0.1, 0.08, 0.28)
    flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
    flash.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(flash)
    var fade := create_tween()
    fade.tween_property(flash, "color:a", 0.0, 0.35)
    fade.tween_callback(flash.queue_free)

func update_rear_alert(enemies: Node3D, player: RunnerPlayer) -> void:
    var behind: int = 0
    for child in enemies.get_children():
        var enemy: RunnerEnemy = child as RunnerEnemy
        if enemy != null and enemy.health > 0.0 and enemy.is_pursuing and enemy.position.z > player.position.z - 38.0:
            behind += 1
    $RearAlert.text = "%d ENEMIES BEHIND" % behind if behind > 0 else ""

func show_message(message: String, seconds: float = 2.5) -> void:
    $Message.text = message
    message_clock = seconds

func update_stats(player: RunnerPlayer, stage: int, stages: int, stage_distance: float, delta: float) -> void:
    $Stats.text = "LEVEL %d/%d   HP %d/%d   SOLDIERS %d   %s   DMG %.1f   CASH $%d   KILLS %d" % [stage, stages, ceili(player.health), int(player.maximum_health), player.soldier_count, player.weapon.to_upper(), player.damage, player.cash, player.kills]
    $Progress.value = clampf(stage_distance / 150.0 * 100.0, 0.0, 100.0)
    message_clock -= delta
    if message_clock <= 0.0:
        $Message.text = ""
