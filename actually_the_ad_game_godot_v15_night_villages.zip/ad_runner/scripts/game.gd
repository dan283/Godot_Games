extends Node3D

const ENEMY_SCENE: PackedScene = preload("res://scenes/enemy.tscn")
const GATE_SCENE: PackedScene = preload("res://scenes/gate.tscn")
const STAGE_LENGTH: float = 150.0

@export_range(1, 20, 1) var level_count: int = 5
@export var random_seed: int = 0
@export var invert_steering: bool = true
@export_group("Gate Health")
@export_range(0.25, 30.0, 0.05) var base_gate_hp: float = 2.45
@export_range(0.5, 5.0, 0.05) var starting_volleys: float = 1.4
@export_range(0.0, 1.0, 0.005) var gate_difficulty_per_level: float = 0.175
@export_range(0.0, 0.5, 0.005) var gate_difficulty_per_upgrade: float = 0.07
@export_group("Sounds — drop AudioStream files here")
@export var projectile_shoot_sound: AudioStream = preload("res://sounds/shoot.wav")
@export var enemy_damage_sound: AudioStream = preload("res://sounds/enemy_hit.wav")
@export var enemy_death_sound: AudioStream = preload("res://sounds/enemy_death.wav")
@export var player_damage_sound: AudioStream = preload("res://sounds/player_hit.wav")
@export var player_death_sound: AudioStream = preload("res://sounds/player_death.wav")
@export var soldier_death_sound: AudioStream = preload("res://sounds/soldier_death.wav")
@export var enemy_attack_sound: AudioStream = preload("res://sounds/enemy_attack.wav")
@export var upgrade_sound: AudioStream = preload("res://sounds/upgrade.wav")

@onready var player: RunnerPlayer = $Player
@onready var hud: RunnerHUD = $HUD
@onready var enemies: Node3D = $Enemies
@onready var projectiles: Node3D = $Projectiles
@onready var gates: Node3D = $Gates
@onready var camera: Camera3D = $Camera3D
@onready var scenery: RunnerScenery = $Scenery
@onready var effects: RunnerEffects = $Effects

var rng := RandomNumberGenerator.new()
var stage: int = 1
var loaded_stage: int = 1
var finished: bool = false
var gate_slots: Array[float] = []
var previous_upgrade: String = ""
var last_enemy_hit_sound_ms: int = -1000
var last_enemy_attack_sound_ms: int = -1000
var camera_shake: float = 0.0
var effect_rng := RandomNumberGenerator.new()
var started: bool = false

func _ready() -> void:
    if random_seed == 0:
        rng.randomize()
    else:
        rng.seed = random_seed
    effect_rng.randomize()
    player.reversed_controls = invert_steering
    var course_length: float = float(level_count) * STAGE_LENGTH
    build_curved_road(course_length)
    scenery.populate(course_length)
    player.fired.connect(func(at: Vector3) -> void: play_sound(projectile_shoot_sound, at))
    player.hurt.connect(_on_player_hurt)
    player.died.connect(func(at: Vector3) -> void: play_sound(player_death_sound, at))
    player.soldier_died.connect(_on_soldier_died)
    player.regenerated.connect(func(at: Vector3) -> void: effects.heal(at))
    build_stage(1)
    hud.character_selected.connect(_on_character_selected)
    hud.show_character_select()

func build_curved_road(course_length: float) -> void:
    var track := Node3D.new()
    track.name = "CurvedRoad"
    add_child(track)
    for preview in [$Road, $LeftLine, $RightLine, $VergeLeft, $VergeRight, $TerrainLeft, $TerrainRight]:
        preview.hide()
    var ground := MeshInstance3D.new()
    var ground_mesh := BoxMesh.new()
    ground_mesh.size = Vector3(120.0, 0.13, course_length + 38.0)
    ground.mesh = ground_mesh
    ground.material_override = $TerrainLeft.material_override
    track.add_child(ground)
    ground.position = Vector3(0.0, -0.18, course_length * 0.5)
    var z: float = -18.0
    while z < course_length + 18.0:
        _road_tile(track, z, 0.0, -0.2, Vector3(13.5, 0.25, 8.75), $Road.material_override)
        _road_tile(track, z, -7.4, -0.16, Vector3(2.2, 0.13, 8.75), $VergeLeft.material_override)
        _road_tile(track, z, 7.4, -0.16, Vector3(2.2, 0.13, 8.75), $VergeRight.material_override)
        _road_tile(track, z, -6.4, -0.055, Vector3(0.12, 0.03, 8.75), $LeftLine.material_override)
        _road_tile(track, z, 6.4, -0.055, Vector3(0.12, 0.03, 8.75), $RightLine.material_override)
        z += 8.0

func _road_tile(track: Node3D, z: float, lane: float, height: float, size: Vector3, material: Material) -> void:
    var piece := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    piece.mesh = box
    piece.material_override = material
    track.add_child(piece)
    piece.position = Vector3(RunnerRoad.center_x(z) + lane, height, z)
    piece.rotation.y = atan(RunnerRoad.slope(z))

func _on_character_selected(choice: String) -> void:
    player.choose_character(choice)
    started = true
    hud.show_message("LEVEL 1  |  STEER LEFT / RIGHT\nAUTO FIRE ON", 3.0)

func _process(delta: float) -> void:
    if not started:
        return
    if finished:
        if Input.is_action_just_pressed("ui_accept") or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
            get_tree().reload_current_scene()
        return
    player.advance(delta, projectiles, enemies, gates)
    if player.health <= 0.0:
        end_run(false)
        return
    if loaded_stage < level_count and player.position.z >= float(loaded_stage) * STAGE_LENGTH - 90.0:
        loaded_stage += 1
        build_stage(loaded_stage)
    camera.global_position = camera.global_position.lerp(player.global_position + Vector3(0.0, 11.0, -18.0), minf(1.0, delta * 6.0))
    camera_shake = maxf(0.0, camera_shake - delta)
    if camera_shake > 0.0:
        camera.global_position += Vector3(effect_rng.randf_range(-1.0, 1.0), effect_rng.randf_range(-1.0, 1.0), 0.0) * camera_shake
    camera.look_at(player.global_position + Vector3(0.0, 0.0, 15.0))
    for child in enemies.get_children():
        var enemy: RunnerEnemy = child as RunnerEnemy
        if enemy != null and not enemy.is_queued_for_deletion():
            enemy.advance(delta, player)
    separate_enemies(delta)
    if player.health <= 0.0:
        end_run(false)
        return
    while not gate_slots.is_empty() and player.position.z >= gate_slots[0] - 34.0:
        var gate_z: float = gate_slots.pop_front()
        spawn_smart_gate_pair(gate_z)
    for child in gates.get_children():
        var gate: RunnerGate = child as RunnerGate
        if gate != null and gate.unlocked and not gate.triggered and absf(gate.position.z - player.position.z) < 0.75 and absf(gate.position.x - player.position.x) < 2.35:
            gate.apply(player)
            play_sound(upgrade_sound, gate.global_position)
            effects.upgrade(gate.global_position, gate.title)
            camera_shake = maxf(camera_shake, 0.09)
            hud.show_upgrade(gate.title, player.weapon)
            player.upgrades_collected += 1
            gate.vanish(true)
            for other_child in gates.get_children():
                var other: RunnerGate = other_child as RunnerGate
                if other != null and other != gate and not other.triggered and absf(other.position.z - gate.position.z) < 0.2:
                    other.vanish(false)
        elif gate != null and not gate.triggered and player.position.z > gate.position.z + 4.0:
            gate.vanish(false)
    var next_stage: int = mini(level_count, 1 + int(player.position.z / STAGE_LENGTH))
    if next_stage != stage:
        stage = next_stage
        player.health = minf(player.maximum_health, player.health + 2.0)
        hud.show_message("LEVEL %d  |  ENEMIES GROW STRONGER" % stage, 3.0)
    hud.update_stats(player, stage, level_count, player.position.z - float(stage - 1) * STAGE_LENGTH, delta)
    hud.update_rear_alert(enemies, player)
    if player.health <= 0.0:
        end_run(false)
    elif player.position.z >= float(level_count) * STAGE_LENGTH - 1.0:
        end_run(true)

func build_stage(number: int) -> void:
    var start: float = float(number - 1) * STAGE_LENGTH
    gate_slots.append(start + 24.0)
    gate_slots.append(start + 65.0)
    gate_slots.append(start + 104.0)
    spawn_pack(start + 48.0, 5 if number == 1 else 5 + number * 2, number)
    spawn_pack(start + 87.0, 7 if number == 1 else 7 + number * 3, number)
    spawn_pack(start + 123.0, 9 if number == 1 else 8 + number * 4, number)
    spawn_enemy(Vector3(RunnerRoad.center_x(start + 144.0), 0.0, start + 144.0), "boss", number)

func spawn_enemy(at: Vector3, kind: String, number: int) -> RunnerEnemy:
    var enemy: RunnerEnemy = ENEMY_SCENE.instantiate() as RunnerEnemy
    enemy.position = at
    enemies.add_child(enemy)
    enemy.configure(kind, number)
    enemy.died.connect(_on_enemy_died)
    enemy.damaged.connect(_on_enemy_damaged)
    enemy.attacked.connect(func(at_position: Vector3) -> void: play_sound(enemy_attack_sound, at_position))
    return enemy

func spawn_pack(z: float, count: int, number: int) -> void:
    for i in range(count):
        var row: int = floori(float(i) / 4.0)
        var side: float = -1.0 if i % 4 < 2 else 1.0
        var spawn_z: float = z + float(row) * 3.3 + float(i % 2) * 0.85 + rng.randf_range(-0.18, 0.18)
        var lane: float = side * (7.25 + float(i % 2) * 1.9 + rng.randf_range(-0.12, 0.12))
        var kind: String = "normal"
        if number > 1 and i % 8 == 0:
            kind = "tank"
        elif number > 2 and i % 5 == 1:
            kind = "fast"
        spawn_enemy(Vector3(RunnerRoad.center_x(spawn_z) + lane, 0.0, spawn_z), kind, number)

func separate_enemies(delta: float) -> void:
    var living: Array[RunnerEnemy] = []
    for child in enemies.get_children():
        var enemy: RunnerEnemy = child as RunnerEnemy
        if enemy != null and enemy.health > 0.0:
            living.append(enemy)
    for i in range(living.size()):
        var a: RunnerEnemy = living[i]
        for j in range(i + 1, living.size()):
            var b: RunnerEnemy = living[j]
            var gap := Vector2(a.position.x - b.position.x, a.position.z - b.position.z)
            if absf(gap.x) > 2.8 or absf(gap.y) > 2.8:
                continue
            var minimum: float = 0.67 * (a.scale.x + b.scale.x)
            var distance: float = gap.length()
            if distance >= minimum:
                continue
            var direction: Vector2 = gap / distance if distance > 0.001 else Vector2(1.0, 0.0)
            var push: Vector2 = direction * minf((minimum - distance) * 0.5, delta * 3.5)
            a.position.x = clampf(a.position.x + push.x, RunnerRoad.center_x(a.position.z) - 9.5, RunnerRoad.center_x(a.position.z) + 9.5)
            a.position.z += push.y
            b.position.x = clampf(b.position.x - push.x, RunnerRoad.center_x(b.position.z) - 9.5, RunnerRoad.center_x(b.position.z) + 9.5)
            b.position.z -= push.y

func spawn_smart_gate_pair(z: float) -> void:
    var options: Array[Dictionary] = []
    var stage_at_gate: int = 1 + int(z / STAGE_LENGTH)
    var boost: int = 1 + int((stage_at_gate - 1) / 2)
    if player.soldier_count < 22:
        options.append({"label": "+%d SOLDIERS" % (2 + boost), "kind": "soldiers", "amount": float(2 + boost), "weight": 4.0})
    if player.damage < 22.0:
        options.append({"label": "+%d DAMAGE" % (1 + boost), "kind": "damage", "amount": float(1 + boost), "weight": 3.0})
    if player.fire_interval > 0.09:
        options.append({"label": "FIRE RATE x1.25", "kind": "fire_rate", "amount": 0.8, "weight": 3.0})
    if player.health < player.maximum_health - 1.5:
        options.append({"label": "+4 HEALTH", "kind": "health", "amount": 4.0, "weight": 5.0 if player.health < 5.0 else 2.0})
    if player.cash_multiplier < 8:
        options.append({"label": "CASH x2", "kind": "multiplier", "amount": 2.0, "weight": 1.5})
    if player.weapon != "scatter":
        options.append({"label": "SCATTER SHOT", "kind": "weapon_scatter", "amount": 1.0, "weight": 1.35})
    if player.weapon != "flame":
        options.append({"label": "FIRE BOMB", "kind": "weapon_flame", "amount": 1.0, "weight": 1.35})
    if player.weapon != "bolt":
        options.append({"label": "ARC BOLT", "kind": "weapon_bolt", "amount": 1.0, "weight": 1.0})
    options.append({"label": "+$%d" % (20 * stage_at_gate), "kind": "cash", "amount": float(20 * stage_at_gate), "weight": 0.9})
    var left: Dictionary = draw_option(options)
    options.erase(left)
    var right: Dictionary = draw_option(options)
    # Both choices help; adapt to current stats and avoid repeating the same type.
    if rng.randf() < 0.5:
        var swap: Dictionary = left
        left = right
        right = swap
    make_gate(-3.1, z, left)
    make_gate(3.1, z, right)
    previous_upgrade = String(left["kind"])

func draw_option(options: Array[Dictionary]) -> Dictionary:
    var total: float = 0.0
    for option in options:
        var weight: float = float(option["weight"])
        if String(option["kind"]) == previous_upgrade:
            weight *= 0.35
        total += weight
    var roll: float = rng.randf_range(0.0, total)
    for option in options:
        var weight: float = float(option["weight"])
        if String(option["kind"]) == previous_upgrade:
            weight *= 0.35
        roll -= weight
        if roll <= 0.0:
            return option
    return options.back()

func make_gate(x: float, z: float, option: Dictionary) -> void:
    var gate: RunnerGate = GATE_SCENE.instantiate() as RunnerGate
    gate.position = Vector3(RunnerRoad.center_x(z) + x, 0.0, z)
    var squad_volley: float = player.damage * (1.0 + 0.7 * float(player.soldier_count - 1))
    var gate_stage: int = 1 + int(z / STAGE_LENGTH)
    var desired_volleys: float = starting_volleys + gate_difficulty_per_level * float(gate_stage - 1) + gate_difficulty_per_upgrade * float(player.upgrades_collected)
    var stage_floor: float = base_gate_hp * (1.0 + gate_difficulty_per_level * float(gate_stage - 1))
    gate.maximum_shield = maxf(stage_floor, squad_volley * desired_volleys)
    gates.add_child(gate)
    gate.configure(String(option["label"]), String(option["kind"]), float(option["amount"]), true)

func _on_enemy_died(enemy: RunnerEnemy) -> void:
    play_sound(enemy_death_sound, enemy.global_position)
    player.kills += 1
    var reward: int = (25 if enemy.kind == "boss" else 2) * player.cash_multiplier
    player.cash += reward
    effects.kill(enemy.global_position, reward, enemy.kind == "boss")
    if enemy.kind == "boss":
        camera_shake = maxf(camera_shake, 0.28)
        hud.show_message("LEVEL %d BOSS DOWN!" % enemy.level, 2.0)

func _on_enemy_damaged(at: Vector3) -> void:
    play_sound(enemy_damage_sound, at)
    effects.hit(at)

func _on_player_hurt(at: Vector3) -> void:
    play_sound(player_damage_sound, at)
    effects.player_damage(at)
    hud.show_damage_flash()
    camera_shake = maxf(camera_shake, 0.27)

func _on_soldier_died(at: Vector3) -> void:
    play_sound(soldier_death_sound, at)
    effects.soldier_down(at)
    hud.show_message("SOLDIER DOWN!", 1.1)

func play_sound(stream: AudioStream, at: Vector3) -> void:
    if stream == null:
        return
    if stream == enemy_damage_sound:
        var now_ms: int = Time.get_ticks_msec()
        if now_ms - last_enemy_hit_sound_ms < 55:
            return
        last_enemy_hit_sound_ms = now_ms
    if stream == enemy_attack_sound:
        var attack_ms: int = Time.get_ticks_msec()
        if attack_ms - last_enemy_attack_sound_ms < 75:
            return
        last_enemy_attack_sound_ms = attack_ms
    var audio := AudioStreamPlayer3D.new()
    audio.stream = stream
    audio.max_distance = 75.0
    audio.unit_size = 15.0
    add_child(audio)
    audio.global_position = at
    audio.finished.connect(audio.queue_free)
    audio.play()

func end_run(victory: bool) -> void:
    finished = true
    player.active = false
    if victory:
        hud.show_message("ALL %d LEVELS CLEARED!  CASH $%d\nPRESS ENTER TO RESTART" % [level_count, player.cash], 999.0)
    else:
        hud.show_message("RUN OVER AT LEVEL %d\nPRESS ENTER TO RESTART" % stage, 999.0)
