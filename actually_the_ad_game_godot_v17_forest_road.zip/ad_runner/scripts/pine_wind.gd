extends Node3D

@export_range(0.0, 0.12, 0.005) var wind_strength: float = 0.035
@export_range(0.2, 2.0, 0.05) var wind_speed: float = 0.8
var wind_clock: float = 0.0
var phase: float = 0.0

func _ready() -> void:
    phase = float(get_instance_id() % 127) * 0.071

func _process(delta: float) -> void:
    wind_clock += delta * wind_speed
    $CanopyPivot.rotation.z = sin(wind_clock + phase) * wind_strength
    $CanopyPivot.rotation.x = sin(wind_clock * 0.69 + phase * 1.3) * wind_strength * 0.6
