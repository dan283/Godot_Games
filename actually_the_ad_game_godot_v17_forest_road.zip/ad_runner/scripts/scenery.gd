extends Node3D
class_name RunnerScenery

# Replace any of these with your own Node3D-rooted PackedScene in the Inspector.
# The model origin should sit at ground level and face any direction.
@export_group("Environment Models")
@export var leafy_tree_model: PackedScene = preload("res://props/tree.tscn")
@export var dead_tree_model: PackedScene = preload("res://props/dead_tree.tscn")
@export var rock_model: PackedScene = preload("res://props/rock.tscn")
@export var gravestone_model: PackedScene = preload("res://props/gravestone.tscn")
@export var shrub_model: PackedScene = preload("res://props/shrub.tscn")
@export var grass_model: PackedScene = preload("res://props/grass_clump.tscn")
@export var ground_patch_model: PackedScene = preload("res://props/ground_patch.tscn")
@export var village_house_model: PackedScene = preload("res://props/villagehouse.tscn")
@export var chapel_model: PackedScene = preload("res://props/villagechapel.tscn")
@export var lantern_model: PackedScene = preload("res://props/villagelantern.tscn")
@export var fence_model: PackedScene = preload("res://props/villagefence.tscn")
@export var pine_model: PackedScene = preload("res://props/pine.tscn")
@export_group("Placement")
@export_range(6.0, 28.0, 1.0) var spacing: float = 10.0
@export var scenery_seed: int = 54821
@export_range(75.0, 250.0, 5.0) var village_spacing: float = 125.0
@export_range(7.0, 18.0, 1.0) var forest_tree_spacing: float = 10.0
@export_group("Deep Forest")
@export_range(3, 10, 1) var forest_rows: int = 5
@export_range(3.5, 14.0, 0.5) var dense_tree_spacing: float = 8.5
@export_range(1.0, 3.0, 0.05) var distant_tree_scale: float = 1.9
@export_range(0.0, 1.0, 0.05) var clearing_frequency: float = 0.14
var lantern_lights: Array[OmniLight3D] = []
var lantern_clock: float = 0.0

func _process(delta: float) -> void:
    lantern_clock += delta
    for i in range(lantern_lights.size()):
        var lamp: OmniLight3D = lantern_lights[i]
        if is_instance_valid(lamp):
            lamp.light_energy = 1.35 + 0.12 * sin(lantern_clock * 6.0 + float(i) * 2.4) + 0.06 * sin(lantern_clock * 13.0 + float(i))

func populate(course_length: float) -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = scenery_seed
    for side in [-1.0, 1.0]:
        var z: float = -9.0 + rng.randf_range(0.0, 4.0)
        while z < course_length + 14.0:
            var roll: float = rng.randf()
            var chosen: PackedScene = leafy_tree_model
            if roll < 0.22:
                chosen = dead_tree_model
            elif roll < 0.45:
                chosen = rock_model
            elif roll < 0.60:
                chosen = gravestone_model
            elif roll < 0.75:
                chosen = shrub_model
            _place(chosen, Vector3(side * rng.randf_range(7.6, 10.8), 0.0, z), rng.randf_range(1.0, 1.55), rng)
            if rng.randf() < 0.55:
                _place(ground_patch_model, Vector3(side * rng.randf_range(7.6, 12.0), 0.0, z + rng.randf_range(-2.2, 2.2)), rng.randf_range(0.7, 1.6), rng)
            if rng.randf() < 0.76:
                _place(grass_model, Vector3(side * rng.randf_range(6.95, 11.2), 0.0, z + rng.randf_range(-3.0, 3.0)), rng.randf_range(0.9, 1.8), rng)
            if rng.randf() < 0.3:
                _place(shrub_model, Vector3(side * rng.randf_range(8.0, 12.3), 0.0, z + rng.randf_range(2.0, 5.0)), rng.randf_range(0.65, 1.1), rng)
            z += rng.randf_range(spacing * 0.72, spacing * 1.38)
    for side in [-1.0, 1.0]:
        var edge_z: float = -12.0
        while edge_z < course_length + 12.0:
            var edge_x: float = side * rng.randf_range(6.5, 8.0)
            _place(grass_model, Vector3(edge_x, 0.0, edge_z), rng.randf_range(1.0, 1.7), rng)
            if rng.randf() < 0.35:
                _place(rock_model, Vector3(side * rng.randf_range(7.2, 8.6), 0.0, edge_z + 1.7), rng.randf_range(0.35, 0.65), rng)
            edge_z += rng.randf_range(5.0, 9.0)
    for side in [-1.0, 1.0]:
        var grove_start: float = 67.0
        while grove_start < course_length + 12.0:
            var grove_z: float = grove_start
            while grove_z < grove_start + 38.0 and grove_z < course_length + 12.0:
                for depth in range(3):
                    _place(pine_model, Vector3(side * (12.3 + float(depth) * 4.2 + rng.randf_range(-1.0, 1.0)), 0.0, grove_z + rng.randf_range(-3.0, 3.0)), rng.randf_range(0.85, 1.40), rng)
                grove_z += forest_tree_spacing
            grove_start += 112.0 + rng.randf_range(-8.0, 8.0)
    # Trees grow denser and taller away from the playable track. Leave occasional
    # gaps around the village so its lights and buildings remain visible.
    for side in [-1.0, 1.0]:
        for row in range(forest_rows):
            var distance: float = 12.0 + float(row) * 5.1
            var z: float = -17.0 + rng.randf_range(0.0, dense_tree_spacing)
            while z < course_length + 26.0:
                var village_clear: bool = fposmod(z - 35.0, village_spacing) < 30.0 and distance < 21.0
                if not village_clear and rng.randf() >= clearing_frequency:
                    var chosen_tree: PackedScene = pine_model if rng.randf() < 0.83 else leafy_tree_model
                    var growth: float = lerpf(1.15, distant_tree_scale, float(row) / maxf(1.0, float(forest_rows - 1)))
                    _place(chosen_tree, Vector3(side * (distance + rng.randf_range(-1.6, 1.6)), 0.0, z + rng.randf_range(-2.0, 2.0)), growth * rng.randf_range(0.8, 1.2), rng)
                    if row < 3 and rng.randf() < 0.42:
                        _place(shrub_model, Vector3(side * (distance - 1.0), 0.0, z + 1.8), rng.randf_range(0.9, 1.7), rng)
                z += dense_tree_spacing * rng.randf_range(0.78, 1.27)
    var village_z: float = 35.0
    var village_side: float = 1.0
    while village_z < course_length - 10.0:
        _place(village_house_model, Vector3(village_side * 14.0, 0.0, village_z), rng.randf_range(0.90, 1.12), rng)
        _place(village_house_model, Vector3(village_side * 18.5, 0.0, village_z + 13.0), rng.randf_range(0.82, 1.05), rng)
        _place(lantern_model, Vector3(village_side * 9.0, 0.0, village_z + 4.0), 1.0, rng)
        _place(lantern_model, Vector3(village_side * 9.1, 0.0, village_z + 20.0), 1.0, rng)
        for fence in range(3):
            _place(fence_model, Vector3(village_side * 11.0, 0.0, village_z - 3.0 + float(fence) * 4.4), 1.0, rng)
        _place(chapel_model, Vector3(-village_side * 17.0, 0.0, village_z + 14.0), rng.randf_range(0.85, 1.05), rng)
        for grave in range(4):
            _place(gravestone_model, Vector3(-village_side * (11.5 + float(grave % 2) * 1.7), 0.0, village_z + 7.0 + float(grave / 2) * 2.2), 1.0, rng)
        village_side = -village_side
        village_z += village_spacing + rng.randf_range(-18.0, 18.0)

func _place(model: PackedScene, at: Vector3, size: float, rng: RandomNumberGenerator) -> void:
    if model == null:
        return
    var prop: Node3D = model.instantiate() as Node3D
    if prop == null:
        push_warning("Environment scene must have a Node3D root: %s" % model.resource_path)
        return
    add_child(prop)
    if model == lantern_model:
        var lamp: OmniLight3D = prop.get_node_or_null("LanternLight") as OmniLight3D
        if lamp != null:
            lantern_lights.append(lamp)
    prop.position = Vector3(at.x + RunnerRoad.center_x(at.z), at.y, at.z)
    if model == village_house_model or model == chapel_model:
        prop.rotation.y = signf(at.x) * PI * 0.5 + rng.randf_range(-0.16, 0.16)
    elif model == fence_model:
        prop.rotation.y = PI * 0.5
    else:
        prop.rotation.y = rng.randf_range(-PI, PI)
    prop.scale = Vector3.ONE * size
