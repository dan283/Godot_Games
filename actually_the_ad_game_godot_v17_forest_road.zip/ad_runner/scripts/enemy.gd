extends Node3D
class_name RunnerEnemy
static var wet_materials: Dictionary = {}

const MODEL_SCENES: Dictionary = {
    "peasant": preload("res://models/peasant.tscn"),
    "hood": preload("res://models/hood.tscn"),
    "knight": preload("res://models/knight.tscn"),
    "bishop": preload("res://models/bishop.tscn"),
    "butcher": preload("res://models/butcher.tscn"),
    "bell": preload("res://models/bell.tscn"),
    "fungus": preload("res://models/fungus.tscn"),
    "doctor": preload("res://models/doctor.tscn"),
    "cathedral": preload("res://models/cathedral.tscn"),
}

signal died(enemy: RunnerEnemy)
signal damaged(at: Vector3)
signal attacked(at: Vector3)

@export_enum("normal", "fast", "tank", "boss") var kind: String = "normal"
@export_range(0.0, 1.5, 0.05) var weave_amount: float = 0.45
var health: float = 2.0
var speed: float = 5.3
var touch_damage: float = 1.0
var hit_cooldown: float = 0.0
var level: int = 1
var visual: CharacterVisual
var is_pursuing: bool = false
var current_run_speed: float = 0.0
var current_lateral_speed: float = 0.0
var movement_clock: float = 0.0
var movement_phase: float = 0.0

func configure(enemy_kind: String, stage: int = 1) -> void:
    kind = enemy_kind
    level = stage
    var model_key: String = "peasant"
    match kind:
        "fast":
            health = 2.0
            speed = 10.8
            model_key = "hood" if stage < 3 else "bell"
        "tank":
            health = 12.0
            speed = 4.2
            model_key = "knight" if stage < 3 else "fungus"
            scale = Vector3.ONE * 1.3
        "boss":
            health = 48.0
            speed = 7.2
            touch_damage = 2.0
            model_key = "bishop" if stage <= 2 else ("doctor" if stage <= 4 else "cathedral")
            scale = Vector3.ONE * 1.75
    if kind == "normal" and stage >= 3:
        model_key = "butcher" if stage % 2 == 1 else "peasant"
    var model_scene: PackedScene = MODEL_SCENES[model_key] as PackedScene
    visual = model_scene.instantiate() as CharacterVisual
    $VisualSlot.add_child(visual)
    for node in visual.find_children("*", "MeshInstance3D", true, false):
        var piece: MeshInstance3D = node as MeshInstance3D
        var original: StandardMaterial3D = piece.material_override as StandardMaterial3D
        if original == null:
            continue
        var material_id: int = original.get_instance_id()
        if not wet_materials.has(material_id):
            var moonlit: StandardMaterial3D = original.duplicate() as StandardMaterial3D
            moonlit.roughness = 0.48 if kind == "boss" else 0.56
            moonlit.metallic = 0.045
            wet_materials[material_id] = moonlit
        piece.material_override = wet_materials[material_id] as StandardMaterial3D
    movement_phase = position.z * 0.17 + position.x * 0.69
    movement_clock = movement_phase
    visual.clock = movement_phase
    visual.animation_speed *= 0.88 + 0.12 * absf(sin(movement_phase))
    if kind == "boss":
        health = 48.0 + float(stage - 1) * 30.0
    else:
        health *= 1.0 + float(stage - 1) * 0.42
    speed *= 1.0 + float(stage - 1) * 0.08

func advance(delta: float, player: RunnerPlayer) -> void:
    if health <= 0.0:
        return
    hit_cooldown = maxf(0.0, hit_cooldown - delta)
    movement_clock += delta
    var ahead: float = global_position.z - player.global_position.z
    if ahead < -0.35:
        is_pursuing = true
    if ahead < 31.0:
        var sway: float = weave_amount * sin(movement_clock * 1.65 + movement_phase)
        if absf(global_position.x - RunnerRoad.center_x(global_position.z)) > 6.0:
            sway += 0.18 * sin(movement_clock * 9.0 + movement_phase)
        if kind == "tank" or kind == "boss":
            sway *= 0.5
        var target_x: float = player.global_position.x + sway
        var desired_side_speed: float = clampf((target_x - global_position.x) * 2.4, -speed * 0.8, speed * 0.8)
        current_lateral_speed = move_toward(current_lateral_speed, desired_side_speed, speed * 2.5 * delta)
        var road_center: float = RunnerRoad.center_x(global_position.z)
        global_position.x = clampf(global_position.x + current_lateral_speed * delta, road_center - 9.5, road_center + 9.5)
        if not is_pursuing:
            var uneven_pace: float = speed * (0.95 + 0.05 * sin(movement_clock * 2.1 + movement_phase))
            current_run_speed = move_toward(current_run_speed, uneven_pace, 7.0 * delta)
            global_position.z -= current_run_speed * delta
            var front_heading: float = -current_lateral_speed / maxf(current_run_speed, 1.0) * 0.42
            visual.rotation.y = lerp_angle(visual.rotation.y, front_heading, minf(1.0, delta * 4.5))
        else:
            # Accelerate into a real chase, retaining each enemy's position.
            var catch_up: float = player.forward_speed + clampf(-ahead * 0.13, 0.5, 3.0)
            current_run_speed = move_toward(current_run_speed, maxf(catch_up, speed), 7.0 * delta)
            global_position.z = minf(global_position.z + current_run_speed * delta, player.global_position.z - 1.25)
            var rear_heading: float = PI + current_lateral_speed / maxf(current_run_speed, 1.0) * 0.42
            visual.rotation.y = lerp_angle(visual.rotation.y, rear_heading, minf(1.0, delta * 4.5))
        visual.set_moving(true)
    var reach: float = 2.1 if kind == "boss" else 1.1
    if absf(global_position.z - player.global_position.z) < 2.6 and absf(global_position.x - player.global_position.x) < reach + 1.0 and hit_cooldown <= 0.0:
        visual.attack()
        attacked.emit(global_position)
        player.receive_enemy_attack(global_position, touch_damage, reach)
        hit_cooldown = 0.85 if kind == "boss" else 1.15

func take_damage(amount: float) -> void:
    if health <= 0.0:
        return
    health -= amount
    visual.hit()
    damaged.emit(global_position)
    if health <= 0.0:
        died.emit(self)
        visual.die()
        get_tree().create_timer(0.42).timeout.connect(queue_free)
