extends Node3D
class_name RunnerWeather

@export_range(20, 140, 1) var particle_count: int = 72
var mode: String = "clear"
var flakes: Array[MeshInstance3D] = []
var rng := RandomNumberGenerator.new()
var rain_mesh: BoxMesh
var snow_mesh: SphereMesh
var rain_material: StandardMaterial3D
var snow_material: StandardMaterial3D
@onready var player: RunnerPlayer = get_parent().get_node("Player") as RunnerPlayer

func _ready() -> void:
    rng.randomize()
    rain_mesh = BoxMesh.new()
    rain_mesh.size = Vector3(0.025, 0.48, 0.025)
    snow_mesh = SphereMesh.new()
    snow_mesh.radius = 0.065
    snow_mesh.height = 0.13
    snow_mesh.radial_segments = 6
    snow_mesh.rings = 3
    rain_material = _weather_material(Color(0.50, 0.69, 0.94, 0.70))
    snow_material = _weather_material(Color(0.77, 0.87, 1.0, 0.91))

func _weather_material(tint: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = tint
    material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    return material

func set_stage(stage: int) -> void:
    mode = "clear" if stage <= 1 else ("rain" if stage % 2 == 0 else "snow")
    for flake in flakes:
        if is_instance_valid(flake):
            flake.queue_free()
    flakes.clear()
    if mode == "clear":
        return
    for i in range(particle_count):
        var flake := MeshInstance3D.new()
        flake.mesh = rain_mesh if mode == "rain" else snow_mesh
        flake.material_override = rain_material if mode == "rain" else snow_material
        flake.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(flake)
        _reset_flake(flake, true)
        flakes.append(flake)

func _reset_flake(flake: MeshInstance3D, scattered: bool) -> void:
    flake.global_position = player.global_position + Vector3(rng.randf_range(-17.0, 17.0), rng.randf_range(1.0, 13.0) if scattered else rng.randf_range(9.0, 13.0), rng.randf_range(-11.0, 28.0))

func _process(delta: float) -> void:
    if mode == "clear" or player == null:
        return
    for i in range(flakes.size()):
        var flake: MeshInstance3D = flakes[i]
        var drift: float = sin(float(i) * 2.31 + Time.get_ticks_msec() * 0.0009) * (0.5 if mode == "snow" else 0.15)
        flake.position += Vector3((drift + 0.8) * delta, (-15.0 if mode == "rain" else -2.6) * delta, player.forward_speed * delta * 0.32)
        if flake.position.y < 0.0 or absf(flake.position.x - player.position.x) > 19.0 or flake.position.z < player.position.z - 15.0 or flake.position.z > player.position.z + 32.0:
            _reset_flake(flake, false)
