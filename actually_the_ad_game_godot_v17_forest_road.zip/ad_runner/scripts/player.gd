extends Node3D
class_name RunnerPlayer

signal fired(at: Vector3)
signal hurt(at: Vector3)
signal died(at: Vector3)
signal soldier_died(at: Vector3)
signal regenerated(at: Vector3)

const PROJECTILE_SCENE: PackedScene = preload("res://scenes/projectile.tscn")
const HUNTER_SCENE: PackedScene = preload("res://models/hunter.tscn")

@export var forward_speed: float = 9.5
@export var sideways_speed: float = 11.0
@export var maximum_health: float = 12.0
@export var hit_slow_multiplier: float = 0.46
@export var hit_slow_duration: float = 0.72

var health: float = 12.0
var damage: float = 1.0
var fire_interval: float = 0.34
var soldier_count: int = 2
var cash: int = 0
var cash_multiplier: int = 1
var kills: int = 0
var active: bool = true
var fire_clock: float = 0.0
var invulnerability: float = 0.0
var sanctuary_timer: float = 0.0
var slow_timer: float = 0.0
var reversed_controls: bool = false
var weapon: String = "bolt"
var visual_level: int = 0
var upgrades_collected: int = 0
var lane_x: float = 0.0
var character_type: String = "hunter"
var passive_regeneration_clock: float = 0.0
var companions: Array[CharacterVisual] = []
var focused_gate: RunnerGate
var nearest_gate: RunnerGate
var rank: int = 1
var weapon_light: OmniLight3D
var muzzle_glow: float = 0.0

@onready var formation: Node3D = $Formation
@onready var visual: CharacterVisual = $Visual

func _ready() -> void:
    position.x = RunnerRoad.center_x(position.z) + lane_x
    refresh_formation()
    weapon_light = OmniLight3D.new()
    weapon_light.position = Vector3(0.0, 1.3, 0.35)
    weapon_light.omni_range = 5.0
    weapon_light.light_energy = 0.0
    weapon_light.shadow_enabled = false
    visual.add_child(weapon_light)

func _process(delta: float) -> void:
    muzzle_glow = maxf(0.0, muzzle_glow - delta * 7.0)
    if weapon_light != null:
        weapon_light.light_energy = muzzle_glow

func choose_character(choice: String) -> void:
    character_type = choice
    match choice:
        "guardian":
            maximum_health = 18.0
            health = 18.0
            soldier_count = 4
            forward_speed = 8.8
            fire_interval = 0.58
            set_weapon("scatter")
        "alchemist":
            maximum_health = 10.0
            health = 10.0
            soldier_count = 2
            fire_interval = 0.48
            set_weapon("flame")
        _:
            maximum_health = 12.0
            health = 12.0
            soldier_count = 2
            fire_interval = 0.31
            set_weapon("bolt")
    refresh_formation()
    _color_outfit()

func set_weapon(new_weapon: String) -> void:
    weapon = new_weapon
    fire_clock = 0.0
    if weapon_light != null:
        weapon_light.light_color = Color(0.35, 0.75, 1.0) if weapon == "bolt" else (Color(1.0, 0.48, 0.19) if weapon == "flame" else Color(1.0, 0.78, 0.35))

func boost_visuals() -> void:
    visual_level += 1
    _show_rank()

func set_rank(new_rank: int) -> void:
    rank = new_rank
    _show_rank()

func _show_rank() -> void:
    var adornments: Node3D = visual.rig.get_node_or_null("RankAdornments") as Node3D
    if adornments == null:
        adornments = Node3D.new()
        adornments.name = "RankAdornments"
        visual.rig.add_child(adornments)
    for child in adornments.get_children():
        child.queue_free()
    var tint: Color = Color(0.31, 0.75, 1.0) if weapon == "bolt" else (Color(1.0, 0.46, 0.18) if weapon == "flame" else Color(1.0, 0.78, 0.33))
    var metal := StandardMaterial3D.new()
    metal.albedo_color = tint
    metal.metallic = 0.42
    metal.roughness = 0.27
    if rank >= 2:
        for side in [-1.0, 1.0]:
            var shoulder := MeshInstance3D.new()
            shoulder.mesh = SphereMesh.new()
            shoulder.material_override = metal
            shoulder.position = Vector3(side * 0.52, 1.16, 0.02)
            shoulder.scale = Vector3(0.39, 0.23, 0.39)
            adornments.add_child(shoulder)
    if rank >= 3 or visual_level >= 3:
        var rune := MeshInstance3D.new()
        rune.mesh = SphereMesh.new()
        var glow := StandardMaterial3D.new()
        glow.albedo_color = tint
        glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        glow.emission_enabled = true
        glow.emission = tint
        rune.material_override = glow
        rune.position = Vector3(0.0, 1.48, 0.38)
        rune.scale = Vector3.ONE * (0.18 + minf(0.14, float(visual_level) * 0.015))
        adornments.add_child(rune)
    if rank >= 4:
        var crest := MeshInstance3D.new()
        var spike := CylinderMesh.new()
        spike.top_radius = 0.02
        spike.bottom_radius = 0.26
        spike.height = 0.55
        crest.mesh = spike
        crest.material_override = metal
        crest.position = Vector3(0.0, 2.5, 0.0)
        adornments.add_child(crest)

func _color_outfit() -> void:
    var tint: Color = Color(0.55, 0.72, 1.0) if character_type == "hunter" else (Color(0.95, 0.72, 0.31) if character_type == "guardian" else Color(0.73, 0.49, 0.94))
    for node in visual.find_children("*", "MeshInstance3D", true, false):
        var mesh: MeshInstance3D = node as MeshInstance3D
        if mesh.name in ["Torso", "ArmL", "ArmR", "CoatTail", "CoatBack", "HatBrim", "HatCrown"]:
            var original: StandardMaterial3D = mesh.material_override as StandardMaterial3D
            if original != null:
                var colored: StandardMaterial3D = original.duplicate() as StandardMaterial3D
                colored.albedo_color = tint
                mesh.material_override = colored

func advance(delta: float, projectiles: Node3D, enemies: Node3D, gates: Node3D) -> void:
    if not active:
        return
    invulnerability = maxf(0.0, invulnerability - delta)
    var move_multiplier: float = hit_slow_multiplier if slow_timer > 0.0 else 1.0
    slow_timer = maxf(0.0, slow_timer - delta)
    var steer: float = Input.get_axis("ui_left", "ui_right")
    if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        steer = (get_viewport().get_mouse_position().x / get_viewport().get_visible_rect().size.x - 0.5) * 2.0
    if reversed_controls:
        steer = -steer
    lane_x = clampf(lane_x + steer * sideways_speed * move_multiplier * delta, -5.8, 5.8)
    position.z += forward_speed * move_multiplier * delta
    position.x = RunnerRoad.center_x(position.z) + lane_x
    if character_type == "guardian":
        passive_regeneration_clock += delta
        if passive_regeneration_clock >= 9.0:
            passive_regeneration_clock = 0.0
            if health < maximum_health:
                health = minf(maximum_health, health + 1.0)
                regenerated.emit(global_position)
    visual.set_moving(true)
    fire_clock -= delta
    if fire_clock > 0.0:
        return
    fire_clock = fire_interval
    var target: Node3D = null
    var rear_target: RunnerEnemy = null
    var best_distance: float = 38.0
    var best_rear_distance: float = 26.0
    for child in enemies.get_children():
        var enemy: RunnerEnemy = child as RunnerEnemy
        if enemy == null or enemy.health <= 0.0:
            continue
        var ahead: float = enemy.global_position.z - global_position.z
        var score: float = absf(ahead) + absf(enemy.global_position.x - global_position.x) * 2.0
        if ahead > 0.0 and score < best_distance:
            target = enemy
            best_distance = score
        elif ahead <= 0.0 and score < best_rear_distance:
            rear_target = enemy
            best_rear_distance = score
    nearest_gate = null
    focused_gate = null
    var gate_distance: float = 32.0
    for child in gates.get_children():
        var gate: RunnerGate = child as RunnerGate
        if gate == null or gate.unlocked or gate.triggered:
            continue
        var ahead: float = gate.global_position.z - global_position.z
        var sideways: float = absf(gate.global_position.x - global_position.x)
        if ahead > 0.5 and ahead < 32.0:
            if nearest_gate == null or ahead + sideways * 0.2 < gate_distance:
                nearest_gate = gate
                gate_distance = ahead + sideways * 0.2
            if sideways < 2.25 and (focused_gate == null or ahead < focused_gate.global_position.z - global_position.z):
                focused_gate = gate
    if focused_gate != null:
        target = focused_gate
    elif rear_target != null and (target == null or best_rear_distance < 9.0):
        target = rear_target
    if target == null:
        visual.rotation.y = atan(RunnerRoad.slope(position.z))
        for companion in companions:
            if is_instance_valid(companion):
                companion.rotation.y = visual.rotation.y
        return
    var rear_shot: bool = target.global_position.z < global_position.z
    visual.rotation.y = (PI if rear_shot else 0.0) + atan(RunnerRoad.slope(position.z))
    fired.emit(global_position)
    muzzle_glow = 1.5 + minf(1.0, float(visual_level) * 0.12)
    shoot_from(visual, target, projectiles, enemies, 1.0)
    for i in range(companions.size()):
        var companion: CharacterVisual = companions[i]
        if is_instance_valid(companion):
            var companion_target: Node3D = target
            if focused_gate != null and rear_target != null and best_rear_distance < 13.0 and i % 3 == 2:
                companion_target = rear_target
            var companion_rear: bool = companion_target.global_position.z < companion.global_position.z
            companion.rotation.y = (PI if companion_rear else 0.0) + atan(RunnerRoad.slope(position.z))
            shoot_from(companion, companion_target, projectiles, enemies, 0.7)

func shoot_from(shooter: CharacterVisual, target: Node3D, projectiles: Node3D, enemies: Node3D, multiplier: float) -> void:
    shooter.attack()
    var pellets: int = (5 if visual_level >= 3 else 3) if weapon == "scatter" and target is RunnerEnemy else 1
    for i in range(pellets):
        var shot: RunnerProjectile = PROJECTILE_SCENE.instantiate() as RunnerProjectile
        projectiles.add_child(shot)
        var direction: float = -1.0 if target.global_position.z < shooter.global_position.z else 1.0
        shot.global_position = shooter.global_position + Vector3((float(i) - float(pellets - 1) * 0.5) * 0.32, 0.9 if shooter != visual else 1.3, direction * 0.7)
        var shot_damage: float = damage * multiplier * (0.46 if weapon == "scatter" else 1.0)
        var pellet_target: Node3D = target
        if weapon == "scatter" and target is RunnerEnemy and i != pellets / 2:
            var best_gap: float = 3.5
            for child in enemies.get_children():
                var nearby: RunnerEnemy = child as RunnerEnemy
                if nearby != null and nearby != target and nearby.health > 0.0:
                    var side: float = nearby.global_position.x - target.global_position.x
                    var gap: float = nearby.global_position.distance_to(target.global_position)
                    if gap < best_gap and ((i < pellets / 2 and side < 0.0) or (i > pellets / 2 and side > 0.0)):
                        pellet_target = nearby
                        best_gap = gap
        var spread: Vector3 = Vector3((float(i) - float(pellets - 1) * 0.5) * 0.42, 0.0, 0.0) if pellet_target == target else Vector3.ZERO
        shot.launch(pellet_target, shot_damage, weapon, enemies, visual_level, spread)

func receive_enemy_attack(at: Vector3, amount: float, radius: float) -> void:
    if not active or sanctuary_timer > 0.0:
        return
    var closest: CharacterVisual = null
    var best: float = radius
    for companion in companions:
        if not is_instance_valid(companion):
            continue
        var distance: float = Vector2(companion.global_position.x - at.x, companion.global_position.z - at.z).length()
        if distance < best:
            best = distance
            closest = companion
    if closest != null:
        kill_companion(closest)
    elif Vector2(global_position.x - at.x, global_position.z - at.z).length() < radius:
        take_damage(amount)

func take_damage(amount: float) -> void:
    if not active or invulnerability > 0.0:
        return
    health = maxf(0.0, health - amount)
    invulnerability = 0.55
    slow_timer = hit_slow_duration
    visual.hit()
    hurt.emit(global_position)
    if health <= 0.0:
        visual.die()
        # Surviving squad members also visibly fall when the run ends.
        for companion in companions:
            if is_instance_valid(companion):
                companion.die()
        died.emit(global_position)

func kill_companion(companion: CharacterVisual) -> void:
    var where: Vector3 = companion.global_position
    companions.erase(companion)
    soldier_count = maxi(1, soldier_count - 1)
    slow_timer = maxf(slow_timer, 0.25)
    companion.reparent(get_parent(), true)
    companion.set_moving(false)
    companion.die()
    soldier_died.emit(where)
    get_tree().create_timer(0.65).timeout.connect(companion.queue_free)
    arrange_formation()

func refresh_formation() -> void:
    # Gate upgrades add soldiers; existing members keep their own animation state.
    while companions.size() < soldier_count - 1:
        var companion: CharacterVisual = HUNTER_SCENE.instantiate() as CharacterVisual
        companion.scale = Vector3.ONE * 0.63
        formation.add_child(companion)
        companion.set_moving(true)
        companions.append(companion)
    while companions.size() > soldier_count - 1:
        var removed: CharacterVisual = companions.pop_back() as CharacterVisual
        removed.reparent(get_parent(), true)
        removed.die()
        get_tree().create_timer(0.65).timeout.connect(removed.queue_free)
    arrange_formation()

func arrange_formation() -> void:
    for i in range(companions.size()):
        var row: int = floori(float(i) / 4.0)
        companions[i].position = Vector3((float(i % 4) - 1.5) * 1.1, 0.0, 0.95 - float(row) * 0.95)
